<?php
/*
Plugin Name: Excerpt first paragraph Dolphin
Plugin URI: 
Description: This plugin will pull the first paragraph as an excerpt.
Version: 1.0.1
Author: Ariful Islam
Author URI: 
License: GPL2
*/
 
if(!function_exists('get_the_content_first_paragraph')) :
function get_the_content_first_paragraph() {
    $content = get_the_content();
    $content = apply_filters('the_content', $content);
    $content = str_replace(']]>', ']]&gt;', $content);
    $content_explode = explode("</p>", $content);
 
    $c = 0; $p = count($content_explode); $return_data = "";
    while($c < $p) {
        $test = strip_tags($content_explode[$c]);
        if($test != '') {
            $return_data = $return_data . $content_explode[$c] . "</p>\n";
            $return_data = preg_replace('/<img[^>]+./','', $return_data);
            break;
        } $c++;
    }
    return $return_data;
}
endif;